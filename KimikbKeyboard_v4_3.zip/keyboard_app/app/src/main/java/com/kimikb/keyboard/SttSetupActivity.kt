package com.kimikb.keyboard

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast

/** Transparent helper: a keyboard can't show permission dialogs, so this does it, then starts the service. */
class SttSetupActivity : Activity() {

    private var lang = "ar"
    private var room = true
    private var srMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        srMode = intent.getStringExtra("mode") == "sr"
        lang = intent.getStringExtra("lang") ?: "ar"
        room = intent.getBooleanExtra("room", true)
        if (room && Build.VERSION.SDK_INT < 29) {
            room = false
            Toast.makeText(this, "التقاط صوت الغرفة يحتاج أندرويد 10+ — سيُستخدم المايك", Toast.LENGTH_LONG).show()
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            proceed()
        } else {
            val perms = if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            else arrayOf(Manifest.permission.RECORD_AUDIO)
            requestPermissions(perms, 1)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        val i = perms.indexOf(Manifest.permission.RECORD_AUDIO)
        if (i >= 0 && res.getOrNull(i) == PackageManager.PERMISSION_GRANTED) proceed()
        else {
            Toast.makeText(this, "صلاحية المايك مطلوبة للكتابة الصوتية", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun proceed() {
        if (srMode) {   // normal dictation: only the permission was needed
            SttBridge.sink.onState("perm_ok")
            finish(); return
        }
        if (room) {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), 2)
        } else startService(0, null)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK && data != null) startService(resultCode, data)
        else {
            Toast.makeText(this, "تم رفض التقاط الصوت", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun startService(code: Int, data: Intent?) {
        val i = Intent(this, RoomListenService::class.java)
            .putExtra("lang", lang).putExtra("room", room).putExtra("code", code)
        if (data != null) i.putExtra("data", data)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        finish()
    }
}
