package com.kimikb.keyboard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/** Foreground service that owns the MediaProjection + the recognition engine. */
class RoomListenService : Service() {

    private var engine: SttEngine? = null
    private var projection: MediaProjection? = null
    @Volatile private var generation = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) { shutdown(); return START_NOT_STICKY }

        val lang = intent.getStringExtra("lang") ?: "ar"
        val room = intent.getBooleanExtra("room", true) && Build.VERSION.SDK_INT >= 29
        startFg(room)
        releaseEngine()
        val gen = ++generation

        if (room) {
            val code = intent.getIntExtra("code", 0)
            val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableExtra("data", Intent::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableExtra("data")
            if (data == null) { SttBridge.sink.onError("لم تُمنح صلاحية التقاط الصوت"); shutdown(); return START_NOT_STICKY }
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mpm.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { shutdown() }
            }, Handler(Looper.getMainLooper()))
        }

        SttBridge.sink.onState(if (SttModels.ready(this, lang)) "loading" else "downloading")
        Thread {
            try {
                if (!SttModels.ready(this, lang)) {
                    SttModels.download(this, lang) { SttBridge.sink.onProgress(it) }
                }
            } catch (e: Throwable) {
                SttBridge.sink.onError("تعذّر تنزيل نموذج اللغة: " + (e.message ?: ""))
                Handler(Looper.getMainLooper()).post { shutdown() }
                return@Thread
            }
            Handler(Looper.getMainLooper()).post {
                if (gen != generation) return@post
                engine = SttEngine(applicationContext, lang, projection).also { it.start() }
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun startFg(room: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "الكتابة الصوتية", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = PendingIntent.getService(this, 0,
            Intent(this, RoomListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH)
        else @Suppress("DEPRECATION") Notification.Builder(this)
        val n = b.setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("كيبوردي — الكتابة الصوتية")
            .setContentText(if (room) "يستمع لصوت الغرفة ويكتبه" else "يستمع للمايك ويكتب")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "إيقاف", stop).build())
            .build()
        when {
            room && Build.VERSION.SDK_INT >= 29 ->
                startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            !room && Build.VERSION.SDK_INT >= 30 ->
                startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else -> startForeground(ID, n)
        }
    }

    private fun releaseEngine() {
        engine?.stop(); engine = null
        runCatching { projection?.stop() }
        projection = null
    }

    private fun shutdown() {
        generation++
        releaseEngine()
        SttBridge.sink.onState("stopped")
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        generation++
        releaseEngine()
        SttBridge.sink.onState("stopped")
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.kimikb.keyboard.STT_STOP"
        private const val CH = "stt"
        private const val ID = 4201
    }
}
