package com.kimikb.keyboard

import android.content.Context

/** علم → (اسم الدولة، العاصمة). يُقرأ من assets/flags.tsv (195 دولة). */
object FlagData {
    class Entry(val flag: String, val country: String, val capital: String)

    private var map: Map<String, Entry>? = null

    private fun load(ctx: Context): Map<String, Entry> {
        map?.let { return it }
        val m = LinkedHashMap<String, Entry>()
        runCatching {
            ctx.assets.open("flags.tsv").bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (l in lines) {
                    val p = l.split('\t')
                    if (p.size >= 3) m[p[0].trim()] = Entry(p[0].trim(), p[1].trim(), p[2].trim())
                }
            }
        }
        map = m
        return m
    }

    fun find(ctx: Context, flag: String): Entry? = load(ctx)[flag]

    /** تفكيك: ف ر ن س ا  (والمسافة بين كلمتين = مسافتان) */
    fun spaced(s: String): String =
        s.trim().split(Regex("\\s+")).joinToString("  ") { w -> w.toCharArray().joinToString(" ") }

    /** يُرجع الأعلام (كل علم = حرفا مؤشر إقليمي) إن كان النص كله أعلاماً فقط، وإلا null */
    fun parseFlags(text: String?): List<String>? {
        if (text.isNullOrBlank() || text.length > 40) return null
        val cps = ArrayList<Int>()
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            i += Character.charCount(cp)
            if (cp == 0xFE0F || cp == 0x200D || cp == 0x200E || cp == 0x200F || Character.isWhitespace(cp)) continue
            if (cp !in 0x1F1E6..0x1F1FF) return null
            cps.add(cp)
        }
        if (cps.size < 2 || cps.size % 2 != 0 || cps.size > 8) return null
        val out = ArrayList<String>()
        var k = 0
        while (k < cps.size) {
            out.add(String(Character.toChars(cps[k])) + String(Character.toChars(cps[k + 1])))
            k += 2
        }
        return out
    }
}
