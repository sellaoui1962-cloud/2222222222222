package com.kimikb.keyboard

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import kotlin.math.abs

class KeySpec(
    val label: String, val token: String, val w: Float = 1f, val hint: String = "",
    val out: String? = null,      // text to commit if different from the label
    val span: Int = 1,            // rows covered (tall send key on the number page)
    val flat: Boolean = false,    // icon only, no key background (globe / mic)
    val h: Float = 1f             // row height weight (taken from the first key of the row)
)

class KeyboardView(context: Context) : View(context) {

    interface Listener {
        fun onText(t: String)        // commit a character / string
        fun onSpecial(token: String) // @DEL @SHIFT @ENTER @SEND @SPACE @LANG @NUM @ABC @EMOJI @SYM @SET
    }

    var listener: Listener? = null
    var rows: List<List<KeySpec>> = emptyList()
        set(v) {
            field = v
            totals = FloatArray(v.size) { r -> v[r].sumOf { it.w.toDouble() }.toFloat().coerceAtLeast(0.1f) }
            weights = FloatArray(v.size) { r -> v[r].firstOrNull()?.h ?: 1f }
            sizeCache.clear()
            layoutRows()
            invalidate()
        }

    private var totals = FloatArray(0)
    private var weights = FloatArray(0)
    private var rowTops = FloatArray(1)
    private val sizeCache = HashMap<KeySpec, Float>()

    private fun layoutRows() {
        val n = rows.size
        rowTops = FloatArray(n + 1)
        val sum = weights.sum().coerceAtLeast(0.1f)
        var acc = 0f
        for (i in 0 until n) { rowTops[i] = height * acc / sum; acc += weights[i] }
        rowTops[n] = height.toFloat()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sizeCache.clear(); layoutRows(); super.onSizeChanged(w, h, ow, oh)
    }

    var micActive = false
        set(v) { if (field != v) { field = v; invalidate() } }

    // theme: 0 light, 1 dark, 2 amoled, 3 ocean
    var theme = 1
    private var pal: Palette = Themes.get(1)

    private val d = context.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private class Ptr(val row: Int, val col: Int, val downX: Float, val key: KeySpec?) {
        var swiped = false
        var consumed = false
        var lp: Runnable? = null
    }
    private val ptrs = HashMap<Int, Ptr>()
    private val longPressHandler = Handler(Looper.getMainLooper())

    private fun isDown(r: Int, c: Int): Boolean {
        for (p in ptrs.values) if (p.row == r && p.col == c) return true
        return false
    }

    private fun cancelLp(p: Ptr) {
        p.lp?.let { longPressHandler.removeCallbacks(it) }
        p.lp = null
    }

    override fun onDetachedFromWindow() {
        longPressHandler.removeCallbacksAndMessages(null)
        ptrs.clear()
        popup?.dismiss()
        super.onDetachedFromWindow()
    }
    private var popup: PopupWindow? = null

    val alternates = mapOf(
        'ا' to "أ إ آ", 'و' to "ؤ", 'ي' to "ئ", 'ة' to "ه", 'ل' to "لا",
        'ء' to "أ إ", 'ى' to "ي ئ", '◌' to "ً ٌ ٍ َ ُ ِ ّ ْ", '´' to "é è ê ë à â ç ù û î ô",
        'e' to "é è ê ë", 'a' to "à â ä", 'i' to "î ï", 'o' to "ô ö",
        'u' to "ù û ü", 'c' to "ç", 'n' to "ñ",
        '.' to ", : ؟ ! ٪ ، … ' ?", '#' to "© ® ™ ° № < > + = *", '?' to "¿", '!' to "¡", '٪' to "؟ ! …", '@' to "# _ / :"
    )

    fun applyTheme(t: Int) {
        theme = t
        pal = Themes.get(t)
        invalidate()
    }

    // service tells view when shift is active so FR letters render uppercase
    var shiftActive = false
        set(v) { if (field != v) { field = v; sizeCache.clear() } }
    var capsActive = false
        set(v) { if (field != v) { field = v; sizeCache.clear() } }
    var showHints = true
    var keyHeightDp = 252
    var keyRadiusDp = 7f
    var textScale = 1f
    private fun shiftUpper() = shiftActive || capsActive

    // constant height on every page => switching pages never re-lays-out the keyboard
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = if (MeasureSpec.getMode(widthMeasureSpec) == MeasureSpec.EXACTLY)
            MeasureSpec.getSize(widthMeasureSpec) else (d * 360).toInt()
        setMeasuredDimension(w, (keyHeightDp * d).toInt())
    }

    private fun shade(c: Int, f: Float): Int {
        val r = (((c shr 16) and 0xFF) * f).toInt().coerceIn(0, 255)
        val g = (((c shr 8) and 0xFF) * f).toInt().coerceIn(0, 255)
        val b = ((c and 0xFF) * f).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    override fun onDraw(canvas: Canvas) {
        paint.style = Paint.Style.FILL
        paint.color = pal.bg
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        if (rows.isEmpty()) return
        val pad = 2.6f * d
        val sh = 1.4f * d
        val radius = keyRadiusDp * d
        var pressedLabel: String? = null
        var pbL = 0f; var pbT = 0f; var pbR = 0f
        for ((ri, row) in rows.withIndex()) {
            var x = 0f
            val total = totals[ri]
            val rowTop = rowTops[ri]
            for ((ci, key) in row.withIndex()) {
                val kw = width * key.w / total
                val tok = key.token
                if (tok == "@COVER" || tok == "@NONE") { x += kw; continue }
                val isPressed = isDown(ri, ci)
                val special = tok.startsWith("@")
                val isEnter = tok == "@SEND"
                val shiftOn = tok == "@SHIFT" && (shiftActive || capsActive)
                val hot = isEnter || shiftOn
                val base = when {
                    hot -> pal.enterBg
                    special -> pal.keyAlt
                    else -> pal.key
                }
                val inset = if (isPressed) 1.6f * d else 0f
                val left = x + pad + inset
                val top = rowTop + pad + inset
                val right = x + kw - pad - inset
                val bottom = rowTops[(ri + key.span).coerceAtMost(rows.size)] - pad - sh - inset
                val cx = (left + right) / 2f
                val cy = (top + bottom) / 2f

                if (key.flat) {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 1.7f * d
                    paint.strokeCap = Paint.Cap.ROUND
                    paint.color = if (tok == "@MIC" && micActive) pal.enterBg
                        else if (isPressed) pal.special else pal.hint
                    val r = minOf(kw, rowTops[ri + 1] - rowTop) * 0.30f
                    if (tok == "@MIC") drawMic(canvas, cx, cy, r) else drawGlobe(canvas, cx, cy, r)
                    paint.style = Paint.Style.FILL
                    x += kw
                    continue
                }

                val fill = if (isPressed) shade(base, if (pal.isLight) 0.88f else 1.35f) else base
                paint.style = Paint.Style.FILL
                rect.set(left, top + sh, right, bottom + sh)
                paint.color = pal.shadow
                canvas.drawRoundRect(rect, radius, radius, paint)
                rect.set(left, top, right, bottom)
                paint.color = fill
                canvas.drawRoundRect(rect, radius, radius, paint)

                var label = key.label
                if (tok == "@SHIFT" && capsActive) label = "⇪"
                if (shiftUpper() && !special) label = label.uppercase()
                paint.textAlign = Paint.Align.CENTER
                paint.color = if (hot) pal.enterText else pal.text
                val rh = bottom - top
                var size = sizeCache[key]
                if (size == null || (shiftUpper() && !special)) {
                    var ts = (rh * 0.40f * textScale).coerceAtMost(kw * 0.46f * textScale)
                    paint.textSize = ts
                    val maxW = kw - pad * 4f
                    while (paint.measureText(label) > maxW && ts > 9f * d) { ts -= 1f; paint.textSize = ts }
                    size = ts
                    sizeCache[key] = ts
                }
                paint.textSize = size
                val yText = cy - (paint.descent() + paint.ascent()) / 2f
                canvas.drawText(label, cx, yText, paint)

                if (showHints && key.hint.isNotEmpty() && !special) {
                    paint.textSize = (rh * 0.19f).coerceAtMost(kw * 0.24f)
                    paint.color = pal.hint
                    paint.textAlign = Paint.Align.RIGHT
                    canvas.drawText(key.hint, right - 4f * d, top + 3f * d - paint.ascent(), paint)
                    paint.textAlign = Paint.Align.CENTER
                }

                if (isPressed && !special) {
                    pbL = left; pbT = top; pbR = right
                    pressedLabel = label
                }
                x += kw
            }
        }

        // key preview bubble above the pressed letter
        val pl = pressedLabel
        if (pl != null) {
            val rhAvg = height.toFloat() / rows.size
            val bw = (pbR - pbL) * 1.4f
            val bh = rhAvg * 1.1f
            val bcx = ((pbL + pbR) / 2f).coerceIn(bw / 2f, width - bw / 2f)
            val btop = (pbT - bh - 2f * d).coerceAtLeast(0f)
            rect.set(bcx - bw / 2f, btop, bcx + bw / 2f, btop + bh)
            paint.style = Paint.Style.FILL
            paint.color = shade(pal.key, if (pal.isLight) 0.97f else 1.5f)
            canvas.drawRoundRect(rect, radius * 1.3f, radius * 1.3f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.5f * d
            paint.color = pal.enterBg
            canvas.drawRoundRect(rect, radius * 1.3f, radius * 1.3f, paint)
            paint.style = Paint.Style.FILL
            paint.color = pal.text
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = bh * 0.5f
            canvas.drawText(pl, rect.centerX(),
                rect.centerY() - (paint.descent() + paint.ascent()) / 2f, paint)
        }
    }

    // ----- line icons (no emoji colours): globe + microphone -----
    private val path = android.graphics.Path()

    private fun drawGlobe(c: Canvas, cx: Float, cy: Float, r: Float) {
        c.drawCircle(cx, cy, r, paint)
        rect.set(cx - r * 0.45f, cy - r, cx + r * 0.45f, cy + r)
        c.drawOval(rect, paint)
        c.drawLine(cx - r, cy, cx + r, cy, paint)
        c.drawLine(cx, cy - r, cx, cy + r, paint)
        rect.set(cx - r * 0.9f, cy - r * 0.55f, cx + r * 0.9f, cy + r * 0.55f)
        c.drawArc(rect, 0f, 180f, false, paint)
        c.drawArc(rect, 180f, 180f, false, paint)
    }

    private fun drawMic(c: Canvas, cx: Float, cy: Float, r: Float) {
        val bw = r * 0.55f
        rect.set(cx - bw, cy - r, cx + bw, cy + r * 0.25f)
        c.drawRoundRect(rect, bw, bw, paint)
        rect.set(cx - r * 0.95f, cy - r * 0.55f, cx + r * 0.95f, cy + r * 0.75f)
        c.drawArc(rect, 0f, 180f, false, paint)
        c.drawLine(cx, cy + r * 0.75f, cx, cy + r * 1.05f, paint)
        c.drawLine(cx - r * 0.45f, cy + r * 1.05f, cx + r * 0.45f, cy + r * 1.05f, paint)
    }

    private fun keyAt(x: Float, y: Float): Pair<Int, Int> {
        if (rows.isEmpty()) return -1 to -1
        var ri = rows.size - 1
        for (i in 0 until rows.size) { if (y < rowTops[i + 1]) { ri = i; break } }
        val row = rows[ri]
        val total = totals[ri]
        var acc = 0f
        var ci = row.lastIndex
        for ((i, key) in row.withIndex()) {
            val kw = width * key.w / total
            if (x < acc + kw) { ci = i; break }
            acc += kw
        }
        // a tall key owns the cells under it
        if (row[ci].token == "@COVER" && ri > 0) return keyAt(x, rowTops[ri] - 1f)
        return ri to ci
    }

    private fun fireKey(k: KeySpec) {
        if (k.token.startsWith("@")) {
            listener?.onSpecial(k.token)
        } else {
            var out = k.out ?: k.label
            if (shiftUpper()) out = out.uppercase()
            listener?.onText(out)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val idx = event.actionIndex
                val id = event.getPointerId(idx)
                val x = event.getX(idx)
                val y = event.getY(idx)
                val (r, c) = keyAt(x, y)
                val key = rows.getOrNull(r)?.getOrNull(c)?.takeIf { it.token != "@NONE" && it.token != "@COVER" }
                val ptr = Ptr(r, c, x, key)
                ptrs[id] = ptr
                if (key != null) {
                    val run = Runnable { onLongPress(ptr, key) }
                    ptr.lp = run
                    longPressHandler.postDelayed(run, 420)
                }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                // swipe left on backspace = delete whole word
                for (i in 0 until event.pointerCount) {
                    val ptr = ptrs[event.getPointerId(i)] ?: continue
                    if (ptr.key?.token == "@DEL" && !ptr.swiped && abs(event.getX(i) - ptr.downX) > 110) {
                        ptr.swiped = true
                        cancelLp(ptr)
                        listener?.onSpecial("@DEL_WORD")
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val id = event.getPointerId(event.actionIndex)
                val ptr = ptrs.remove(id)
                if (ptr != null) {
                    cancelLp(ptr)
                    val k = ptr.key
                    if (k != null && !ptr.consumed && !ptr.swiped) fireKey(k)
                }
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                for (p in ptrs.values) cancelLp(p)
                ptrs.clear()
                invalidate()
            }
        }
        return true
    }

    private fun chipView(text: String, sp: Float, onClick: () -> Unit): TextView =
        TextView(context).apply {
            this.text = text
            textSize = sp
            gravity = Gravity.CENTER
            setTextColor(pal.text)
            background = GradientDrawable().apply {
                setColor(pal.key)
                cornerRadius = 10f * d
            }
            val p = (14f * d).toInt()
            setPadding(p, p / 2, p, p / 2)
            setOnClickListener { onClick() }
        }

    private fun addChip(row: LinearLayout, tv: TextView) {
        val m = (3f * d).toInt()
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(m, m, m, m)
        row.addView(tv, lp)
    }

    private fun showRowPopup(row: LinearLayout) {
        val pd = (6f * d).toInt()
        row.setPadding(pd, pd, pd, pd)
        row.background = GradientDrawable().apply {
            setColor(pal.bg)
            cornerRadius = 14f * d
            setStroke((1f * d).toInt().coerceAtLeast(1), pal.keyAlt)
        }
        popup?.dismiss()
        val anchor: View = this
        val pw = PopupWindow(row, ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.setBackgroundDrawable(ColorDrawable(0))
        pw.isOutsideTouchable = true
        pw.elevation = 10f * d
        pw.showAtLocation(anchor, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL,
            0, anchor.height + (4f * d).toInt())
        popup = pw
    }

    private fun onLongPress(ptr: Ptr, key: KeySpec) {
        ptr.lp = null
        when (key.token) {
            "@DEL" -> { ptr.consumed = true; showDeletePopup(); return }
            "@SET" -> { ptr.consumed = true; listener?.onSpecial("@SET_LONG"); return }
            "@NUM" -> { ptr.consumed = true; listener?.onSpecial("@NUMPAD"); return }
            "@SEND" -> { ptr.consumed = true; listener?.onSpecial("@ENTER"); return }
            "@MIC" -> { ptr.consumed = true; listener?.onSpecial("@MIC_LONG"); return }
            "@LANG" -> { ptr.consumed = true; listener?.onSpecial("@LANG_BACK"); return }
        }
        val alts = alternates[key.label.firstOrNull()] ?: return
        ptr.consumed = true
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        alts.split(" ").filter { it.isNotEmpty() }.forEach { ch ->
            addChip(row, chipView(ch, 22f) {
                listener?.onText(ch)
                popup?.dismiss()
            })
        }
        showRowPopup(row)
    }

    private fun showDeletePopup() {
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("⌫ حرف|@DEL", "✕ كلمة|@DEL_WORD", "🗑 الكل|@DEL_ALL").forEach { item ->
            val sep = item.indexOf('|')
            val txt = item.substring(0, sep)
            val tok = item.substring(sep + 1)
            addChip(row, chipView(txt, 15f) {
                listener?.onSpecial(tok)
                popup?.dismiss()
            })
        }
        showRowPopup(row)
    }
}
