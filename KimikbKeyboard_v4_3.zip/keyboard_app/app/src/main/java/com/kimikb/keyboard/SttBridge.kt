package com.kimikb.keyboard

import android.os.Handler
import android.os.Looper

/** Same-process bridge: engine/service threads -> keyboard UI (always delivered on main thread). */
object SttBridge {
    interface Sink {
        fun onPartial(t: String)
        fun onFinal(t: String)
        fun onState(s: String)      // idle | downloading | loading | listening | stopped
        fun onProgress(p: Int)
        fun onError(m: String)
    }

    @Volatile var ui: Sink? = null
    @Volatile var state: String = "idle"

    fun active(): Boolean = state == "downloading" || state == "loading" || state == "listening"

    private val h = Handler(Looper.getMainLooper())

    /** Engine and service talk to this object; it forwards to the keyboard. */
    val sink = object : Sink {
        override fun onPartial(t: String) { h.post { ui?.onPartial(t) } }
        override fun onFinal(t: String) { h.post { ui?.onFinal(t) } }
        override fun onState(s: String) { state = s; h.post { ui?.onState(s) } }
        override fun onProgress(p: Int) { h.post { ui?.onProgress(p) } }
        override fun onError(m: String) { h.post { ui?.onError(m) } }
    }
}
