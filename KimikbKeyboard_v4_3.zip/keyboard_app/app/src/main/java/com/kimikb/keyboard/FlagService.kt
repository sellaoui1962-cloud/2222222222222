package com.kimikb.keyboard

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

/**
 * 1) يقرأ آخر رسالة فيها أعلام فقط (مثل 🇫🇷) في شاشة الغرفة.
 * 2) يضغط زر الإرسال الأخضر الموجود يسار خانة الكتابة.
 */
class FlagService : AccessibilityService() {

    companion object {
        @Volatile var instance: FlagService? = null
        @Volatile var watching = false
        @Volatile var listener: ((List<String>) -> Unit)? = null
        @Volatile var last: List<String> = emptyList()
    }

    private val main = Handler(Looper.getMainLooper())
    private var scheduled = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (!watching || scheduled) return
        scheduled = true
        main.postDelayed({ scheduled = false; scanNow() }, 250)
    }

    // ---------- helpers ----------

    private fun appRoots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        runCatching {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) continue
                w.root?.let { out.add(it) }
            }
        }
        if (out.isEmpty()) rootInActiveWindow?.let { out.add(it) }
        return out
    }

    private inline fun walk(root: AccessibilityNodeInfo, limit: Int = 4000, f: (AccessibilityNodeInfo) -> Unit) {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var n = 0
        while (stack.isNotEmpty() && n < limit) {
            val node = stack.removeLast()
            n++
            f(node)
            for (i in 0 until node.childCount) node.getChild(i)?.let { stack.add(it) }
        }
    }

    // ---------- flag reading ----------

    /** يمسح الشاشة ويرسل أحدث (الأسفل) رسالة أعلام فقط إلى الكيبورد */
    private var lastCount = 0

    fun scanNow(silent: Boolean = false) {
        var bestTop = Int.MIN_VALUE
        var best: List<String>? = null
        var count = 0
        val r = Rect()
        for (root in appRoots()) {
            walk(root) { node ->
                val t = node.text?.toString() ?: node.contentDescription?.toString()
                val fl = FlagData.parseFlags(t)
                if (fl != null && node.isVisibleToUser) {
                    count++
                    node.getBoundsInScreen(r)
                    if (r.top > bestTop) { bestTop = r.top; best = fl }
                }
            }
        }
        val b = best
        if (b == null) { lastCount = 0; return }
        // علم جديد = علم مختلف، أو رسالة أعلام إضافية ظهرت (حتى لو نفس العلم)
        val fresh = b != last || count > lastCount
        last = b
        lastCount = count
        if (fresh && !silent) listener?.invoke(b)
    }

    // ---------- green send button ----------

    private fun screenW() = resources.displayMetrics.widthPixels

    private fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 40)).build()
        dispatchGesture(g, null, null)
    }

    /** يضغط الزر الأخضر (أقصى يسار صف خانة الكتابة). يُرجع false إن لم يجد خانة الكتابة. */
    fun clickGreenSend(): Boolean {
        val er = Rect()
        val r = Rect()
        for (root in appRoots()) {
            var edit: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (edit == null) walk(root) { n ->
                if (edit == null && n.isEditable && n.isVisibleToUser) edit = n
            }
            val e = edit ?: continue
            e.getBoundsInScreen(er)
            val cy = er.centerY()
            var target: AccessibilityNodeInfo? = null
            var targetLeft = Int.MAX_VALUE
            walk(root) { n ->
                if (n.isClickable && n.isVisibleToUser && !n.isEditable) {
                    n.getBoundsInScreen(r)
                    val fits = r.centerY() in (er.top - 20)..(er.bottom + 20) &&
                        r.right <= er.left + 20 && r.width() < screenW() / 4
                    if (fits && r.left < targetLeft) { targetLeft = r.left; target = n }
                }
            }
            val t = target
            if (t != null) {
                if (t.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                t.getBoundsInScreen(r)
                tap(r.exactCenterX(), r.exactCenterY())
                return true
            }
            // احتياطي: ضغطة في مكان الزر الأخضر المعتاد (يسار الصف)
            tap(screenW() * 0.07f, cy.toFloat())
            return true
        }
        return false
    }
}
